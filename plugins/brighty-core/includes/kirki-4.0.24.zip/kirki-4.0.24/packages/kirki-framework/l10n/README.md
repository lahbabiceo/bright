# l10n
A simple package to allow loading a 2nd textdomain (like from a framework like Kirki) in your WordPress theme.
